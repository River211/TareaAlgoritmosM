#include <stdio.h>
#include <stdlib.h>

int main()
{
 int i;
 for(i=0; i < 10; i++) // Loop 10 times.
 {
 puts("Hello, world!\n"); // put the string to the output.
 }
 return 0; // Tell OS the program exited without errors.
}
